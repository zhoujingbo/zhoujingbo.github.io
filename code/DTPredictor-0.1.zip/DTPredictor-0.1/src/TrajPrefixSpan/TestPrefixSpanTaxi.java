package TrajPrefixSpan;

import grid.Configuration;
import grid.Grid;


import java.io.IOException;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import TrajPrefixSpan.PrefixSpanDT.AlgoPrefixSpan;
import TrajPrefixSpan.PrefixSpanDT.AlgoPrefixSpanFP;
import TrajPrefixSpan.PrefixSpanDT.Itemset;
import TrajPrefixSpan.PrefixSpanDT.Sequence;
import TrajPrefixSpan.PrefixSpanDT.SequenceDatabase;

import loadData.SQLiteDriver;



public class TestPrefixSpanTaxi {
	
	private static HashMap<String,Integer> IdMap;
	private static int MOid;
	

	
	
	private SequenceDatabase TraTaxiLoad2SequenceDatabase(String db, String table, String startTime,
			String endTime,String status) {
		IdMap=new HashMap<String,Integer>();
		MOid=0;
		
	//	setMovingObjParameter(Configuration.TaxiLatMin,Configuration.TaxiLngMin,double inStep0)
		
		
		
		SequenceDatabase resSD = new SequenceDatabase(); 
		
		SQLiteDriver.openDB(db);
		if(status.equals("")||status.length()<=1){
		SQLiteDriver.loadTaxiDB(table, startTime, endTime);
		}else{
			SQLiteDriver.loadTaxiDB(table, startTime, endTime,status);
		}
	
		 HashMap<Integer,Sequence> seqMap=new  HashMap<Integer,Sequence> () ;//stor all the sequences
	 
		 try {
			while (SQLiteDriver.rs.next()) {
				MovingObject mo = this.ParseMovingObject(SQLiteDriver.rs);
				Sequence moSeq=seqMap.get(mo.id);
				if(null==moSeq){
					moSeq=new Sequence(mo.id);
					seqMap.put(mo.id, moSeq);
				}
				Itemset itemset = new Itemset();
				itemset.addItem(mo.keyXY);
				moSeq.addItemset(itemset);
				
	    		//moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Set<Entry<Integer,Sequence> > seqSet=seqMap.entrySet();
		Iterator<Entry<Integer,Sequence>> seqItr=seqSet.iterator();
		while(seqItr.hasNext()){
			Entry<Integer,Sequence> entrySeq=seqItr.next();
			resSD.addSequence(entrySeq.getValue());
		}
		
		return resSD; 
	}
	
	 /**
	  * parsing moving object from string
	  * @param res
	  * @return
	  */
	 private MovingObject ParseMovingObject(ResultSet sqlRs){
		 MovingObject mo=new MovingObject();
		 try{
		 mo.timeStamp=SQLiteDriver.getSeconds(sqlRs.getString("time"));
		 mo.id=getMOid(sqlRs.getString("id"));
		 //!!!!lat and lng is reversed
		 mo.lng=sqlRs.getDouble("lat");
		 mo.lat=sqlRs.getDouble("lng");
		 mo.v=sqlRs.getDouble("v");	
		 
		 mo.tranferToGrid();
		 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 return mo;
	 }
	 
	 	private static double lat0;
		private static double lng0;
		private static double step0;
		
		
		private void CalibrationParameter(double minLat, double minLng,
				double maxLat, double maxLng,int gridDivided) {

			lat0 = minLat;
			lng0 = minLng;

			double xScale = maxLat - minLat;
			double yScale = maxLng - minLng;

			double maxScale = (xScale > yScale) ? xScale : yScale;
			int divided = gridDivided;
			step0 = maxScale / divided;
		}
		
	 //parsing moving objects
		public void setMovingObjParameter(double inLat0,double inLng0,double inStep0){
			lat0=inLat0;
			lng0=inLng0;
			step0=inStep0;
		}
		

		
		
		/**
		 * get the id of moving object
		 * @param idStr
		 * @return
		 */
		private static int getMOid(String idStr){
			Integer id=IdMap.get(idStr);
			if(null==id){
				Integer newId=MOid;
				IdMap.put(idStr, newId);
				MOid++;
			return newId;
			} else{
				return id;
			}
			
		}
		
		
		private class MovingObject {
			
			
			int id = -1;
		
			//int sequence = -1;
			//int classId = -1;
			int timeStamp = -1;
			double lat = -1;
			double lng = -1;
			double v = -1;

			int gridX = -1;
			int gridY = -1;
			int keyXY=-1;

			public void tranferToGrid() {
				double offx = lat - lat0;
				double offy = lng - lng0;
				gridX = (int) ( offx / (step0));
				gridY = (int) ( offy / (step0));
				
				int tempX=gridX<<16;
				int tempY=gridY<<16;//clear high
				keyXY=tempX+(tempY>>16);
	
		}
		}
		
		
		public static void main(String [] arg) throws IOException{    
			
			TestPrefixSpanTaxi tpst=new TestPrefixSpanTaxi();
			
			
			// Load a sequence database
			tpst.CalibrationParameter(Configuration.TaxiLatMin,Configuration.TaxiLngMin,
					 Configuration.TaxiLatMax, Configuration.TaxiLngMax,256);
			SequenceDatabase sequenceDatabase = tpst.TraTaxiLoad2SequenceDatabase("data/taxi/taxi.db", "PrefixSpanTest", "00:00:00", "01:00:00","") ; 
		    System.out.println("finish loading...");
			
			
			
			//	sequenceDatabase.loadFile(fileToPath("contextPrefixSpan.txt"));
			// print the database to console
			//sequenceDatabase.print();
			
			// Create an instance of the algorithm 
		 
		    AlgoPrefixSpanFP algo = new AlgoPrefixSpanFP();
		    // AlgoPrefixSpan algo = new AlgoPrefixSpan();
			
			   System.out.println("Start mining by PrefixSpan...");
			// execute the algorithm with minsup = 50 %
			algo.runAlgorithm(sequenceDatabase, 0.5);    
			  System.out.println("finish PrefixSpan...");
			algo.printStatistics(sequenceDatabase.size());
		}
		
	
}
