package loadData;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;


import prediction.GridFilter;
import query.QueryTra;


import grid.Grid;
import grid.GridCell;
import grid.GridLeafTraHashItem;
import grid.MoveObjCache;
import grid.RoICell;
import grid.TraListItem;
import traStore.TraStore;
import traStore.TraStoreListItem;
import visulalization.VisGrid;

/**
 Max x is: 21178.060402969797
Max y is: 30165.0
Min x is: 1137.78709826074
min y is: 4420.849142492672
 * @author workshop
*/
public class BrinkhoffLoad {
	 double lat0=0;//the origin point of whole coordinate latitude
	 double lng0=0;//the origin point of whole coordinate longitude
	 double step=0;//4X4, four level of grid, approximate one meter width for each grid cell
	 
	 double xScale=0;
	 double yScale=0;
	 
	 double divided=-1;
	 
	 double maxX,maxY,minX,minY;
	 
	 public double globalThreshold;
	 
	 private HashMap<Integer,MovingObject> MOSet;//collect current moving object, a auxiliary data structure.
	 
	 //record the sample trajectory part to do experiment
	 private HashMap<Integer,ArrayList<RoICell>> sampleHash;
	 private int sampleNum;
	 private int sampleLen;
	 private int[] sampleIdx;
	 
	 public BrinkhoffLoad(){
		 MOSet=new HashMap<Integer,MovingObject>();
		 
		 maxX=-1;
		 maxY=-1;
		 
		 minX=1000000;
		 minY=1000000;
		 
		 globalThreshold=-1;
		 
		 //record the sample, for experiment
		 sampleHash=null;
		 sampleNum=-1;
		 sampleLen=-1;
		 sampleIdx=null;
	 }
	
	 
	 public void removeSample(){
		 sampleHash=null;
		 sampleNum=-1;
		 sampleLen=-1;
	 }
	 
	 private void CalibrationParameter(){
		 
		 lat0=minX;
		 lng0=minY;
		 
		 xScale=maxX-minX;
		 yScale=maxY-minY;
		 
		double maxScale=(xScale>yScale)?xScale:yScale;
		divided=1000;
		step=maxScale/divided;
	 }
	 
	 
	 public void setSample(int inSampleNum,int inSampleLen){
		 
		 sampleHash=new HashMap<Integer,ArrayList<RoICell>> ();
		
		 sampleNum=inSampleNum;
		 sampleLen=inSampleLen; 
		 
		// for(int i=0;i<sampleNum;i++){
		//	 sampleList.add(new ArrayList<RoICell>());			  
		// }	 
	 }
	 
	 private void setSampleIds(){
		 if(sampleLen!=-1){
		 Iterator<Entry<Integer,MovingObject>> moItr=MOSet.entrySet().iterator();
		 int resIdx=0;
		 sampleIdx=new int[sampleNum];
		 int count=0;
		 int interval=MOSet.size()/sampleNum;
		 while(moItr.hasNext()){
			 Entry<Integer,MovingObject> moItem=moItr.next();
			if(count%interval==1&&resIdx<sampleIdx.length){
				
				sampleIdx[resIdx]=moItem.getKey();
				resIdx++;
			}
			count++;
		 }
		 } 
	 }
	 
	 private void prosSampleResList(HashMap<Integer,ArrayList<RoICell>> sh ){
		 Iterator<Entry<Integer,ArrayList<RoICell>>> shItr=sh.entrySet().iterator();
		 while(shItr.hasNext()){
			 Entry<Integer,ArrayList<RoICell>> item=shItr.next();
			 if(item.getValue().size()>=this.sampleLen){
				 this.sampleHash.put(item.getKey(), item.getValue());
			 }
		 }
	 }
	 
	 public HashMap<Integer,ArrayList<RoICell>> getSampleList(){
		 return this.sampleHash;
	 }
	 
	 public Grid BrinkoffLoad(String fileName){
		 MOSet.clear();
		 
		 CollectMaxMin(fileName);
		   
		 CalibrationParameter();
		 
		 setSampleIds();
		 
		 MOSet.clear();
 
		 MapLoc2Grid.setParameter(this.lat0, this.lng0, this.step);
		 
		 Grid g=TraBrinkoffLoad(fileName);
		 
		 //this.globalThreshold=this.computeThreshold(lr.resGrid);
		// lr.resGrid.setThreshold(this.globalThreshold);
		 return g; 
	 }
	 
/**
 * 
 * @param fileName
 * @return
 */
	 private void CollectMaxMin(String fileName){
			//Grid g=new Grid();
			//TraStore ts=new TraStore();
	    try{
	    	FileInputStream infile=new FileInputStream(fileName);
	    	DataInputStream inData=new DataInputStream(infile);
	    	BufferedReader br=new BufferedReader(new InputStreamReader(inData));
	    	
	    	String strLine;
	    	while((strLine=br.readLine())!=null){
	    	String[] res=strLine.split("	");
	    	MovingObject mo=ParseMovingObject(res);
	    	MOSet.put(mo.id,mo);
	    	proMaxMin(mo);
	    	}
	    	br.close();
	    	inData.close();
	    	infile.close();
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	    
	 }
	 
	 
	 
	/**
	 * 
	 * @param file
	 * @return
	 */
	public Grid TraBrinkoffLoad(String file){
		Grid g=new Grid();
		
		MoveObjCache moc=new MoveObjCache(g);
		
		if(this.sampleNum>0){
			moc.setSample(this.sampleIdx, sampleLen);
		}
		//TraStore ts=new TraStore();
    try{
    	FileInputStream infile=new FileInputStream(file);
    	DataInputStream inData=new DataInputStream(infile);
    	BufferedReader br=new BufferedReader(new InputStreamReader(inData));
    	
    	String strLine;
    	while((strLine=br.readLine())!=null){
    	String[] res=strLine.split("	");
    	
    	MovingObject mo=this.ParseMovingObject(res);
    	mo.tranferToGrid();
    	if(res[0].equals("newpoint")){
    		MOSet.put(mo.id,mo);
      		//g.updatePoint(mo.gridX,mo.gridY, mo.timeStamp,mo.id,mo.sequence);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    		
    	} else if(res[0].equals("point")){
    		MovingObject preMO=MOSet.get(mo.id);
    		if(preMO==null){
    			System.out.println("error");
    			return null;
    		}
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp, mo.gridX, mo.gridY, mo.timeStamp, mo.id);
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp,preMO.sequence,
    		//		mo.gridX, mo.gridY, mo.timeStamp, mo.sequence, mo.id);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    		MOSet.put(mo.id,mo);
    	
    		
    	}else if(res[0].equals("disappearpoint")){
    		MovingObject preMO=MOSet.get(mo.id);
    		if(preMO==null){
    			System.out.println("error");
    			return null;
    		}
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp, mo.gridX, mo.gridY, mo.timeStamp, mo.id);
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp,preMO.sequence,
    		//		mo.gridX, mo.gridY, mo.timeStamp, mo.sequence, mo.id);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    		MOSet.remove(mo.id);
    	}
    	
    	//ts.appendTra(mo.id,mo.lat ,mo.lng, mo.timeStamp);//append
       	
    	}
    	
    	if(null!=this.sampleHash){
    		this.prosSampleResList(moc.getGridSampleHashList());
    	}
    	
    	MOSet.clear();
    	br.close();
    	inData.close();
    	infile.close();
    }catch(Exception e){
    	e.printStackTrace();
    }
    return g;
	}
	
	
	 /**
	  * parsing moving object from string
	  * @param res
	  * @return
	  */
	 private MovingObject ParseMovingObject(String[] res){
		 MovingObject mo=new MovingObject();
		 mo.id=Integer.parseInt(res[1]);
		 mo.sequence=Integer.parseInt(res[2])-1;//as sequence number starts from 1
		 mo.classId=Integer.parseInt(res[3]);
		 mo.timeStamp=Integer.parseInt(res[4]);
		 mo.lat=Double.parseDouble(res[5]);
		 mo.lng=Double.parseDouble(res[6]);
		 mo.v=Double.parseDouble(res[7]);		 
		 
		 return mo;
	 }
	

	 
	 /**
	  * find maximum and minimum of x and y of one line
	  * @param mo
	  */
	 private void proMaxMin(MovingObject mo){
		 minX=((minX>mo.lat)? mo.lat:minX);
		 minY=(minY>mo.lng)?mo.lng:minY;
		 maxX=(maxX>mo.lat)?maxX:mo.lat;
		 maxY=(maxY>mo.lng)?maxY:mo.lng;
	 }
	 
	 private class MovingObject{
			int id=-1;
			int sequence=-1;
			int classId=-1;
			int timeStamp=-1;
			double lat=-1;
			double lng=-1;
			double v=-1;
			
			int gridX=-1;
			int gridY=-1;
			
			private void tranferToGrid(){
					double offx=lat-lat0;
					double offy=lng-lng0;
				
					gridX=(int)(offx/step);
					gridY=(int)(offy/step);
				 
			 }
	 }
	 
	 
	 private RoICell transferToGrid(double lat,double lng){
		 double offx=lat-lat0;
			double offy=lng-lng0;
		
		int gridX=(int)(offx/step);
		int	gridY=(int)(offy/step);
			
		return new RoICell(gridX,gridY);
	 }
	 
	 /**
	  * Load the recent trajectory for query
	  * @param queryFile
	  * @return
	  */
	 public ArrayList<TraStoreListItem> loadRecentTra(String queryFile){
		 
		 ArrayList<TraStoreListItem> resTra=null;
		 try{
			 FileInputStream file=new FileInputStream(queryFile);
			 DataInputStream ds=new DataInputStream(file);
			 
			 BufferedReader bf=new BufferedReader(new InputStreamReader(ds));
			 String lineStr="";
			 resTra=new ArrayList<TraStoreListItem>();
			 while((lineStr=bf.readLine())!=null){
					String[] res=lineStr.split("\t+");
			    	
			    	MovingObject mo=this.ParseMovingObject(res);
			    	mo.tranferToGrid();
			    	
			    	resTra.add(new TraStoreListItem(mo.lat,mo.lng,mo.timeStamp));
			    	
			 }
			 
		 }catch(Exception e){
			 e.printStackTrace();
			 return null;
		 }
		 
		 return resTra;
	 }
	 

	 
	/**
	 * 
	 * @param g
	 */
	 public void statisticAllCell(Grid g){
			int[] hm=new int[100];
			double hmStep=0.4;
			
			
			int maxX=(int)(xScale/(step));
			int maxY=(int)(yScale/(step));
			
			for(int i=0;i<maxX;i++){
				for(int j=0;j<maxY;j++){
					
					GridCell gitem=g.getGridCell(i,j);
					
					if(gitem!=null){
						int index=(int)(gitem.density/hmStep);
						if(index>=100) index=99;
						hm[index]++;
					}
					else{
						hm[0]++;
					}
				}
			}
			
			System.out.println("density number_of_cell");
			for(int i=0;i<100;i++){
				System.out.println(i*hmStep+" "+hm[i]);
			}
			
		}


/*	 public void testThreshold(Grid g){
		 int maxX=(int)(xScale/(step));
		 int maxY=(int)(yScale/(step));
		 
		 double t=g.EstimateThreshold(0,0, maxX, maxY);
		 System.out.println("Threshold is:"+t);
	 }*/
	 
	 private void prinMaxMin(){
		 System.out.println("Max x is: "+maxX);
		 System.out.println("Max y is: "+maxY);
		 System.out.println("Min x is: "+minX);
		 System.out.println("min y is: "+minY);
	 }
	 
	 
	 public static void main(String[] args){
		 //ParameterTest();
		//  DebugTest();
		//  selectAndShow(10139,30,2);
		 
		// testDiscrete();
	 }
	 
	 
	 
}


//JUNK
/**
 * more details are tested by this function. The problem is that, the recent trajectory is simulated by a set of 
 * grid
 *//*
public static void test(){

		
	 BrinkhoffLoad bf=new BrinkhoffLoad();
		LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
		
		//bf.statisticAllCell(lr.resGrid); statistic the distribution of cells
		// bf.prinMaxMin(); print the maximum and minimum of the map, it give a bound of the map location
		//bf.testThreshold(lr.resGrid); compute and print the threshold
		
		VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,1000,1000);//show a map
		
		// public QueryTra(Grid inGrid,TraStore inTraStore,double inLat0,double inLng0,double inStep,double inThreshold,int inQueryConstraintX, int inQueryConstraintY,int inQueryDivided)
		QueryTra qbt=new QueryTra(lr.resGrid,lr.resTraStore, 
				bf.lat0, bf.lng0, bf.step, lr.resGrid.getGlobalThreshold(), 8, 8, 4);
				
		ArrayList<Point> gridPos=new ArrayList<Point>();
		//gridPos.add(new Point(534,436));
		//gridPos.add(new Point(494,447));
		*//**one experiment
		gridPos.add(new Point(493,30));
		gridPos.add(new Point(490,42));
		 gridPos.add(new Point(489,49));
		//gridPos.add(new Point(487,59));*//*
		
		*//**two experiment
		gridPos.add(new Point(404,410));
		gridPos.add(new Point(406,417));*//*
		
		*//**three experiment
		 * 
		 *//*
		gridPos.add(new Point(726,424));
		gridPos.add(new Point(724,404));
	
		
		
		long start=System.currentTimeMillis();
		long startQuery=System.currentTimeMillis();
		Hashtable<Integer,TraListItem> interRes=qbt.QueryTraMultiCell(gridPos);		

		Hashtable<Integer,ArrayList<TraStoreListItem>> traSet
		  				= qbt.QueryFutureTraSet(interRes, 10, lr.resTraStore);
		long endQuery=System.currentTimeMillis();
		System.out.println("time for query:"+(endQuery-startQuery));
		System.out.println("number of reference trajectory:"+traSet.size());
		
		//qbt.visitQueryResult(interRes, traSet); 
		//vg.setDrawMap(false);
		//vg.visQueryResult( traSet,bf.lat0,bf.lng0,bf.step);
		
		
		lr.resGrid.setEnlargeR(4);
		GridFilter gf=new GridFilter(lr.resGrid,traSet,bf.lat0,bf.lng0,bf.step);
		
		//vg.visTimeTraState(gf.timeTraState);
		
		
		double map=gf.MAPEsitmation();
		long end=System.currentTimeMillis();
		System.out.println("total time:"+(end-start));
		System.out.println("MAP is:"+map);
		gf.visitMAPPath();
		
		
		//gf.visitTimeTraState();
		//gf.visitW_kk();

		//Hashtable<Integer,ArrayList<TraStoreListItem>> radomTraSet
		//	=bf.selectTestTra(lr.resTraStore, 17461, 0,5);

		 Hashtable<Integer,ArrayList<TraStoreListItem>> radomTraSet
		 				=bf.randomTestTra(lr.resTraStore, 10, 10);

		 vg.setDrawMap(true);
		 vg.visQueryResult(radomTraSet, bf.lat0,bf.lng0, bf.step);
}*/

/*
public static void DebugTest(){
	 
	 int futureTime=25;
	 
	 BrinkhoffLoad bf=new BrinkhoffLoad();
		LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
	 
	 VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,1000,1000);//show a map
	 
	// public QueryTra(Grid inGrid,TraStore inTraStore,double inLat0,double inLng0,double inStep,double inThreshold,int inQueryConstraintX, int inQueryConstraintY,int inQueryDivided)
	QueryTra qbt=new QueryTra(lr.resGrid,lr.resTraStore, 
				bf.lat0, bf.lng0, bf.step, lr.resGrid.getGlobalThreshold(), 4, 4, 2);
	long start=System.currentTimeMillis();

	//get the test trajectory
	Hashtable<Integer,ArrayList<TraStoreListItem>>   testTra=bf.selectTestTra(lr.resTraStore, 10139, 23, 5);
	ArrayList<TraStoreListItem> recentTra=testTra.get(10139);
	
	
	long startQuery=System.currentTimeMillis();
	//query reference trajectories
	Hashtable<Integer,ArrayList<TraStoreListItem>> traSet=qbt.QueryByRecentTra(recentTra, futureTime);
	long endQuery=System.currentTimeMillis();
	//qbt.visitQueryFutureTra(traSet);//the queried result of the trajectory( there is only one trajectory in traSet.
	//vg.setDrawMap(true);
	//vg.visQueryResult( traSet,bf.lat0,bf.lng0,bf.step);
	
	
	
	lr.resGrid.setEnlargeR(4);
	long startStateGen=System.currentTimeMillis();
	GridFilter gf=new GridFilter(lr.resGrid,traSet,bf.lat0,bf.lng0,bf.step);
	long endStateGen=System.currentTimeMillis();
	//gf.visitTimeTraState();//print of the state for grid filter
	
	long startMAP=System.currentTimeMillis();
	double map=gf.MAPEstimationThreshold(0.1);
	//gf.MAPEsitmation();
	long endMAP=System.currentTimeMillis();
	
	long end=System.currentTimeMillis();
	System.out.println("total time:"+(end-start));
	System.out.println("time for query tra:"+(endQuery-startQuery));
	System.out.println("time for state generalization:"+(endStateGen-startStateGen));
	System.out.print("time for MAP:"+(endMAP-startMAP));
	
	//gf.visitMAPPath();//print of the predicted path

	//vg.visTimeTraState(gf.timeTraState);//visualization of the state of grid filter
	vg.visMAPPath(gf.timeTraState,gf.getMAPPath());//visualization of predicted path
	
	//int len=recentTra.size();
	//vg.visMovingObject(recentTra.get(len-1).lat, recentTra.get(len-1).lng, bf.lat0, bf.lng0, bf.step);
}*/


/*
public static void ParameterTest(){
	 BrinkhoffLoad bf=new BrinkhoffLoad();
	 LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
	
	 bf.testThreshold(lr.resGrid);
		
}
*/

/*

public void testComponent(){
	 BrinkhoffLoad bf=new BrinkhoffLoad();
		LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
		
		bf.statisticAllCell(lr.resGrid);
		 bf.prinMaxMin();
		bf.testThreshold(lr.resGrid);
		
		VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,1000,1000);
		
		QueryTra qbt=new QueryTra(lr.resGrid,lr.resTraStore);
				
		ArrayList<Point> gridPos=new ArrayList<Point>();
		gridPos.add(new Point(534,436));
		gridPos.add(new Point(494,447));
		
		Hashtable<Integer,TraListItem> interRes=qbt.QueryTraMultiCell(gridPos, 10, 10, 0.04);		

		  
		Hashtable<Integer,ArrayList<TraStoreListItem>> traSet
		  				= qbt.QueryFutureTraSet(interRes, 10, lr.resTraStore);
		qbt.visitQueryResult(interRes, traSet); 
		//vg.visQueryResult(interRes, traSet,bf.lat0,bf.lng0,bf.step);
		
		 
}

public Hashtable<Integer,ArrayList<TraStoreListItem> > randomTestTra(TraStore ts,int num,int delta){
	 
	 int count=0;
	 
	 Hashtable<Integer,ArrayList<TraStoreListItem>> res
	 			=new Hashtable<Integer,ArrayList<TraStoreListItem>>();
	 
	 while(count<num){
		 
	 int rdnTraId=(int)(Math.random()*ts.getTraNum());
	 
	 int off=(int)(Math.random()*ts.getLengthOfTra(rdnTraId))/2;
	 
	 ArrayList<TraStoreListItem> item=ts.queryTraByIdOff(rdnTraId, off, delta);
	 
	 res.put(rdnTraId, item);
	 
	 count++;
	 
	 }
	 
	 return res;
}

*//**
 * first test data: traId 17461, off 5
 * @param ts
 * @param traId
 * @param offset
 * @param delta
 * @return
 *//*
public Hashtable<Integer,ArrayList<TraStoreListItem>> selectTestTra(TraStore ts,int traId,int offset,int delta){
	 
	 Hashtable<Integer,ArrayList<TraStoreListItem>> res
		=new Hashtable<Integer,ArrayList<TraStoreListItem>>();
	 ArrayList<TraStoreListItem> item=ts.queryTraByIdOff(traId, offset, delta);
	 
	 res.put(traId, item);
	 
	 return res;
	 
}



*//**
 *  select a trajectories for test
 *//*
public static void selectAndShow(int traId,int off,int delta){
	 
	 BrinkhoffLoad bf=new BrinkhoffLoad();
		LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
	 
		VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,1000,1000);//show a map
		
	// Hashtable<Integer,ArrayList<TraStoreListItem>> radomTraSet
	//	=bf.selectTestTra(lr.resTraStore, 17461, 0,5);
		
		Hashtable<Integer,ArrayList<TraStoreListItem>> radomTraSet
			=bf.selectTestTra(lr.resTraStore, traId, off,delta);

	 //Hashtable<Integer,ArrayList<TraStoreListItem>> radomTraSet
	 //				=bf.randomTestTra(lr.resTraStore, 10, 10);

	 vg.setDrawMap(true);
	 vg.visQueryResult(radomTraSet, bf.lat0,bf.lng0, bf.step);

}


public static void testDiscrete(){
	 BrinkhoffLoad bf=new BrinkhoffLoad();
	LoadRes lr= bf.BrinkoffLoad("data/brinkhoff/oldenburg_time1000_objtime20.dat");
	 
	//get the test trajectory
	Hashtable<Integer,ArrayList<TraStoreListItem>>   testTra=bf.selectTestTra(lr.resTraStore, 10139, 29, 5);
	ArrayList<TraStoreListItem> recentTra=testTra.get(10139);
	
	ArrayList<RoICell> cellArray=new ArrayList<RoICell>();
	
	for(int i=0;i<5;i++){
		RoICell rc=bf.transferToGrid(recentTra.get(i).lat, recentTra.get(i).lng);
		cellArray.add(rc);
	}
	
	
	 ArrayList<Entry<Long,GridLeafTraHashItem>> res=lr.resGrid.queryRangeTimeSeqCells(cellArray,
			 8,8, 5000,0.5);
		 
	
	 
	 VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,1000,1000);//show a map
	 vg.setDrawMap(true);
	 vg.visQueryResultByGrid(res);
	//vg.visQueryResult( traSet,bf.lat0,bf.lng0,bf.step);
	 
	 
}*/

/* public double computeThreshold(Grid g){
int maxX=(int)(xScale/step);
int maxY=(int)(yScale/step);

double t=g.EstimateThreshold(0, 0, maxX,maxY);

return t;
//g.setThreshold(t);
}*/

