package loadData;
import grid.Grid;
import grid.GridCell;

import java.awt.Point;
import java.io.*;
import java.util.ArrayList;

import traStore.TraStore;
import visulalization.VisGrid;
public class AthensLoad {
	/*
	//Truck  select max(x),max(y),mind(x),min(y) from trucksTable   => 24.0178|38.296553|23.509963|37.810268
	//max(x)-min(x)=0.507837    max(y)-min(y)=0.485925
	//therefore
	//x0=23.5, y0=37.8
	 double Latf0=0;
	 double Lngf0=0;
	 double step=0;//4X4, four level of grid, approximate one meter width for each grid cell
	 
	 double latScale=0;
	 double lngScale=0;
	 
	 double divided=-1;
	
	//load the trajectory into database, from trajectory to DB
	public LoadRes TraAthensLoad(String fileName){
		Grid g=new Grid();
		TraStore ts=new TraStore();
    try{
		 //open the trajectory data file
		FileInputStream  fstream=new FileInputStream(fileName);
		//Get the object of data stream
		DataInputStream dataStream=new DataInputStream(fstream);
		BufferedReader br=new BufferedReader(new InputStreamReader(dataStream));
		
		if(fileName.contains("Trucks")){
			//Truck  select max(x),max(y),min(x),min(y) from trucksTable   => 24.0178|38.296553|23.509963|37.810268
			//max(x)-min(x)=0.507837    max(y)-min(y)=0.485925
			//therefore
			//x0=23.5, y0=37.8
			
			//divided=65536;
			divided=65536;
			  Latf0=23.509963*1e6;
			  Lngf0=37.810268*1e6;
			  step=0.6*1e6/divided;//4X4, four level of grid, approximate one meter width for each grid cell
			  latScale=0.507837;
			  lngScale=0.485925;
		}else{
			//select max(x),max(y),min(x),min(y) from busesTable;   =>  24.020317|38.74166|22.333144|37.83292
			//max(x)-min(x)=1.687173    max(y)-min(y)=0.90874
			//therefore
			//x0=23.5, y0=37.8
			divided=655360;
			 Latf0=22.333144*1e6;
			 Lngf0=37.83292*1e6;
			 step=1.8*1e6/divided;//4X4, four level of grid, approximate one meter width for each grid cell
			 
			 latScale=1.687173;
			 lngScale=0.90874;
		}
		
		String strLine;
		
		//ArrayList<String> elems=new ArrayList<String>();
		
		String oldObjId="",oldTraId="",curObjId="",curTraId="",oldDate="",curDate="",curTime="",cur;
		int tra=-1,off=-1;
		String traStr,offStr;
		//Read File Line By Line
		
		int traId=-1,dt=-1;
		Point p=new Point(-1,-1);
		int oldTraObjId=-1,oldTraDt=-1,oldX=-1,oldY=-1;
		
		while((strLine=br.readLine())!=null){
			//elems.clear();
		    String elems[]=strLine.split(";");
		    for(int i=0;i<elems.length;i++){
		    	System.out.print(elems[i]+" ");
		    }
		    System.out.println();
			//split(strLine,';',elems);
		    
		     traId=this.ObjTra2Int(elems[0],elems[1]);//trajectory id
		     dt=this.DateTime2Int(elems[2],elems[3]);//date and time
		     p=this.LatLng2XY(elems[4],elems[5]);
		    
		    curObjId=elems[0];
			curTraId=elems[1];
			curDate=elems[2];
			
			//the main part for trajectory load into memeory
		if((curObjId.equals(oldObjId))&&(curTraId.equals(oldTraId))&&(curDate.equals(oldDate))){
				off++;
				//g.updateLineTra(oldX, oldY, oldTraDt,off-1, (int)(p.x), (int)(p.y),off, dt, traId);
				g.updatePoint((int)(p.x), (int)(p.y), dt,traId,off);//start point
				
				
				
				double latf=Double.parseDouble(elems[4])*1e6;
				double lngf=Double.parseDouble(elems[5])*1e6;
				ts.appendTra(traId,(int)(latf) ,(int)(lngf), dt);//append
				//countTra++;
		}
		else{//start a new trajectory
				tra++;
				off=0;
				
				g.updatePoint((int)(p.x), (int)(p.y), dt,traId,off);//start point
				
				double latf=Double.parseDouble(elems[4])*1e6;
				double lngf=Double.parseDouble(elems[5])*1e6;
				ts.appendTra(traId,(int)(latf) ,(int)(lngf), dt);//append
				//countTra++;
		}
		
		oldTraObjId=traId;
		oldTraDt=dt;
		oldX=(int)p.x;
		oldY=(int)p.y;
		
		oldObjId=curObjId;
		oldTraId=curTraId;
		oldDate=curDate;
		}
		
		br.close();
		dataStream.close();
		fstream.close();
		
		}catch(Exception e){
				e.printStackTrace();
				return null;
			}
		return new LoadRes(g,ts);
	}
	
	*//**
	 * transfer the date and time in file to be integer
	 * @param date
	 * @param time
	 * @return
	 *//*
	public int DateTime2Int(String date,String time){
		int t=-1;
		
		String[] dateArray=date.split("/");
		int day=0,month=0,year=0;
		day=Integer.parseInt(dateArray[0]);
		month=Integer.parseInt(dateArray[1]);
		//year=Integer.parseInt(dateArray[2]);
		
		String[] timeArray=time.split(":");
		int second=0,minute=0,hour=0;
		hour=Integer.parseInt(timeArray[0]);
		minute=Integer.parseInt(timeArray[1]);
		second=Integer.parseInt(timeArray[2]);
		
		//t=(day+month*30+year*365)*24*3600+(hour*60+minute)*60+second;
		t=(day+month*30)*24*3600+(hour*60+minute)*60+second;
		
		return t;
	}
	
	*//**
	 * tranfer the object id and trajectory id to a unique identifier
	 * @param objId
	 * @param traId
	 * @return
	 *//*
	public int ObjTra2Int(String objId,String traId){
		
		int id=-1;
		id=Integer.parseInt(objId+traId);
		return id;
	}
	
	
	*//**
	 * transfer lat and lng to x-y coordination of grid map
	 * @param lat
	 * @param lng
	 * @return
	 *//*
	public Point LatLng2XY(String lat,String lng){
		
	
		double latf=Double.parseDouble(lat)*1e6;
		double lngf=Double.parseDouble(lng)*1e6;
		
		double offx=latf-Latf0;
		double offy=lngf-Lngf0;
		
		int x=(int)((int)offx/((int)step));
		int y=(int)((int)offy/((int)step));

		return new Point(x,y);
	}


	
	*//**
	 * for test, visit all the cellss
	 * @param g
	 *//*
	public void visitAllCells(Grid g){
		GridCell[][] gc=g.gridArray;
		int count=0;
		
		int maxX=(int)(0.507837*1e6/(step));
		int maxY=(int)(0.485925*1e6/(step));
		for(int i=0;i<maxX;i++){
			for(int j=0;j<maxY;j++){
				
				GridCell gitem=g.getGridCell(i,j);
				
				if(gitem!=null){
					count++;
				}
			}
		}
		System.out.println(count);
	}
	
	public void visitCell(Grid g){
		GridCell gc=g.getGridCell(4365, 659);
		
		if(gc!=null&&gc.traList!=null){
			for(int i=0;i<gc.traList.size();i++){
				System.out.println("gc cell 4338, 655: "+gc.traList.get(i).traId);
			}
			
		}
	}
	

	
	public void statisticOneCell(Grid g,double inLat,double inLng){
		int[] hm=new int[100];
		double hmStep=1;
		//23.853369 38.008643
		double centerLat=inLat*1e6-Latf0;
		double centerLng=inLng*1e6-this.Lngf0;
		
		int centerX=(int)(centerLat/(step));
		int centerY=(int)(centerLng/(step));
		
		//int maxX=(int)(0.507837*1e6/(step));
		//int maxY=(int)(0.485925*1e6/(step));
		
		for(int i=centerX-1000;i<centerX+1000;i++){
			for(int j=centerY-1000;j<centerY+1000;j++){
				
				GridCell gitem=g.getGridCell(i,j);
				
				if(gitem!=null){
					int index=(int)(gitem.density/hmStep);
					if(index>=100) index=99;
					hm[index]++;
				}
				else{
					hm[0]++;
				}
			}
		}
		
		for(int i=0;i<100;i++){
			System.out.println(i+"-th hm is: "+hm[i]);
		}
		
	}
	
	
	public void statisticAllCell(Grid g){
		int[] hm=new int[100];
		double hmStep=1;
		
		
		int maxX=(int)(latScale*1e6/(step));
		int maxY=(int)(lngScale*1e6/(step));
		
		for(int i=0;i<maxX;i++){
			for(int j=0;j<maxY;j++){
				
				GridCell gitem=g.getGridCell(i,j);
				
				if(gitem!=null){
					int index=(int)(gitem.density/hmStep);
					if(index>=100) index=99;
					hm[index]++;
				}
				else{
					hm[0]++;
				}
			}
		}
		
		for(int i=0;i<100;i++){
			System.out.println(i+"-th hm is: "+hm[i]);
		}
		
	}
public  static void main( String args[]){
		
		AthensLoad al=new AthensLoad();
		LoadRes loadRes=al.TraAthensLoad("data/trucks/Trucks.txt");
		//LoadRes loadRes=al.TraAthensLoad("data/buses/Buses.txt");
		
		//ArrayList<TraStoreListItem> item=loadRes.resTraStore.traHash.get(9211);
		
		
		//System.out.println("lat: "+item.get(0).lat+" lng: "+item.get(0).lng+" time: "+item.get(0).timestamp);
		
		//item=loadRes.resTraStore.traHash.get(9201);
		///int idx=item.size()-1;
		//System.out.println("lat: "+item.get(idx).lat+" lng: "+item.get(idx).lng+" time: "+item.get(idx).timestamp);
		
		//al.visitAllCells(loadRes.resGrid);
		
		//al.visitCell(loadRes.resGrid);
		
		//al.statisticAllCell(loadRes.resGrid);
		VisGrid.visGridPart(loadRes.resGrid, 0, 0, 600,600);
	}
*/	
}
