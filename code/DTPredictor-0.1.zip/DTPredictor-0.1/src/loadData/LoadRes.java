package loadData;

import traStore.TraStore;
import grid.Grid;

public class LoadRes {

	public Grid resGrid=null;

	public LoadRes(Grid g){
		resGrid=g;
	
	}
}


//junk
//public TraStore resTraStore=null;

/*public LoadRes(Grid g,TraStore t){
	resGrid=g;
	resTraStore=t;
}
*/