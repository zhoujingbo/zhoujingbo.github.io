package loadData;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;




import prediction.GridFilter;
import query.QueryTra;

import grid.Grid;
import grid.GridCell;
import grid.MoveObjCache;
import grid.RoICell;
import grid.RoIState;
import grid.TraListItem;
import traStore.TraStore;
import traStore.TraStoreListItem;
import visulalization.VisGrid;

/**
 Max x is: 21178.060402969797
Max y is: 30165.0
Min x is: 1137.78709826074
min y is: 4420.849142492672
 * @author workshop
 *
 *
 */
public class ToyLoad {
	 double lat0=0;//the origin point of whole coordinate latitude
	 double lng0=0;//the origin point of whole coordinate longitude
	 double step=0;//4X4, four level of grid, approximate one meter width for each grid cell
	 
	 double xScale=0;
	 double yScale=0;
	 
	 double divided=-1;
	 
	 double maxX,maxY,minX,minY;
	 
	// public double globalThreshold;
	 
	 private HashMap<Integer,MovingObject> MOSet;//collect current moving object, a auxiliary data structure.
	 
	 public ToyLoad(){
		 MOSet=new HashMap<Integer,MovingObject>();
		 
		 maxX=-1;
		 maxY=-1;
		 
		 minX=100;
		 minY=100;
	 }
	 
	 private void CalibrationParameter(){
		 
		 lat0=minX;
		 lng0=minY;
		 
		 xScale=maxX-minX;
		 yScale=maxY-minY;
		 
		double maxScale=(xScale>yScale)?xScale:yScale;
		divided=50;
		step=maxScale/divided;
	 }
	 
	 public Grid BrinkoffLoad(String fileName){
		 
		 CollectMaxMin(fileName);
		 
		 CalibrationParameter();
		 
		 MapLoc2Grid.setParameter(this.lat0, this.lng0, this.step);
		 
		 Grid g=TraBrinkoffLoad(fileName);
		 
		 //this.globalThreshold=this.computeThreshold(lr.resGrid);
		// lr.resGrid.setThreshold(this.globalThreshold);
		 return g;
	 }
	 
	 /**
	  * Load the recent trajectory for query
	  * @param queryFile
	  * @return
	  */
	 public ArrayList<TraStoreListItem> loadRecentTra(String queryFile){
		 
		 ArrayList<TraStoreListItem> resTra=null;
		 try{
			 FileInputStream file=new FileInputStream(queryFile);
			 DataInputStream ds=new DataInputStream(file);
			 
			 BufferedReader bf=new BufferedReader(new InputStreamReader(ds));
			 String lineStr="";
			 resTra=new ArrayList<TraStoreListItem>();
			 while((lineStr=bf.readLine())!=null){
					String[] res=lineStr.split("\t+");
			    	
			    	MovingObject mo=this.ParseMovingObject(res);
			    	mo.tranferToGrid();
			    	
			    	resTra.add(new TraStoreListItem(mo.lat,mo.lng,mo.timeStamp));
			    	
			 }
			 
		 }catch(Exception e){
			 e.printStackTrace();
			 return null;
		 }
		 
		 return resTra;
	 }
	 
	 
	 
/**
 * 
 * @param fileName
 * @return
 */
	 private void CollectMaxMin(String fileName){
		
	    try{
	    	FileInputStream infile=new FileInputStream(fileName);
	    	DataInputStream inData=new DataInputStream(infile);
	    	BufferedReader br=new BufferedReader(new InputStreamReader(inData));
	    	
	    	String strLine;
	    	while((strLine=br.readLine())!=null){
	    	String[] res=strLine.split("\t+");
	    	MovingObject mo=ParseMovingObject(res);
	    	
	    	proMaxMin(mo);
	    	}
	    	br.close();
	    	inData.close();
	    	infile.close();
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	    
	 }
	 
	 
	public Grid TraBrinkoffLoad(String file){
		Grid g=new Grid();
		MoveObjCache moc=new MoveObjCache(g);
		//TraStore ts=new TraStore();
    try{
    	FileInputStream infile=new FileInputStream(file);
    	DataInputStream inData=new DataInputStream(infile);
    	BufferedReader br=new BufferedReader(new InputStreamReader(inData));
    	
    	String strLine;
    	while((strLine=br.readLine())!=null){
    	String[] res=strLine.split("\t+");
    	
    	MovingObject mo=this.ParseMovingObject(res);
  
    	mo.tranferToGrid();

    	if(res[0].equals("newpoint")){
    		MOSet.put(mo.id,mo);
      		//g.updatePoint(mo.gridX,mo.gridY, mo.timeStamp,mo.id,mo.sequence);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    		
    		
    	} else if(res[0].equals("point")){
    		MovingObject preMO=MOSet.get(mo.id);
    		if(preMO==null){
    			System.out.println("error");
    			return null;
    		}
    		
    	//	g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp,preMO.sequence,
    		//		mo.gridX, mo.gridY, mo.timeStamp, mo.sequence, mo.id);
    		
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp, mo.gridX, mo.gridY, mo.timeStamp, mo.id);
    	
    		MOSet.put(mo.id,mo);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    		
    	}else if(res[0].equals("disappearpoint")){
    		//g.updatePoint(mo.gridX,mo.gridY, mo.timeStamp,mo.id,mo.sequence);
    		MovingObject preMO=MOSet.get(mo.id);
    		if(preMO==null){
    			System.out.println("error");
    			return null;
    		}
    		//g.updateLineTra(preMO.gridX,preMO.gridY, preMO.timeStamp, mo.gridX, mo.gridY, mo.timeStamp, mo.id);
    		
    		MOSet.remove(mo.id);
    		moc.update(mo.id, mo.lat, mo.lng, mo.timeStamp);
    	}
    	
    	//ts.appendTra(mo.id,mo.lat ,mo.lng, mo.timeStamp);//append
       	
    	}
    	MOSet.clear();
    	br.close();
    	inData.close();
    	infile.close();
    }catch(Exception e){
    	e.printStackTrace();
    }
    return g;
	}
	 /**
	  * parsing moving object from string
	  * @param res
	  * @return
	  */
	 private MovingObject ParseMovingObject(String[] res){
		 MovingObject mo=new MovingObject();
		 mo.id=Integer.parseInt(res[1]);
		 mo.sequence=Integer.parseInt(res[2])-1;//as sequence number starts from 1
		 mo.classId=Integer.parseInt(res[3]);
		 mo.timeStamp=Integer.parseInt(res[4]);
		 mo.lat=Double.parseDouble(res[5]);
		 mo.lng=Double.parseDouble(res[6]);
		 mo.v=Double.parseDouble(res[7]);		 
		 
		 return mo;
	 }
	
	 

	 
	 /**
	  * find maximum and minimum of x and y of one line
	  * @param mo
	  */
	 private void proMaxMin(MovingObject mo){
		 minX=((minX>mo.lat)? mo.lat:minX);
		 minY=(minY>mo.lng)?mo.lng:minY;
		 maxX=(maxX>mo.lat)?maxX:mo.lat;
		 maxY=(maxY>mo.lng)?maxY:mo.lng;
	 }
	 
	 private class MovingObject{
			int id=-1;
			int sequence=-1;
			int classId=-1;
			int timeStamp=-1;
			double lat=-1;
			double lng=-1;
			double v=-1;
			
			int gridX=-1;
			int gridY=-1;
			
			private void tranferToGrid(){
					double offx=lat-lat0;
					double offy=lng-lng0;
				
					gridX=(int)((int)offx/((int)step));
					gridY=(int)((int)offy/((int)step));
				 
			 }
	 }
	/**
	 * 
	 * @param g
	 */
	 public void statisticAllCell(Grid g){
			int[] hm=new int[100];
			double hmStep=0.4;
			
			
			int maxX=(int)(xScale/(step));
			int maxY=(int)(yScale/(step));
			
			for(int i=0;i<maxX;i++){
				for(int j=0;j<maxY;j++){
					
					GridCell gitem=g.getGridCell(i,j);
					
					if(gitem!=null){
						int index=(int)(gitem.density/hmStep);
						if(index>=100) index=99;
						hm[index]++;
					}
					else{
						hm[0]++;
					}
				}
			}
			
			System.out.println("density number_of_cell");
			for(int i=0;i<100;i++){
				System.out.println(i*hmStep+" "+hm[i]);
			}
			
		}


	
	 private void prinMaxMin(){
		 System.out.println("Max x is: "+maxX);
		 System.out.println("Max y is: "+maxY);
		 System.out.println("Min x is: "+minX);
		 System.out.println("min y is: "+minY);
	 }
	 

	 
	 public static void main(String[] args){
		
		
	 }
	 
}

//JUNK
/*public void testThreshold(Grid g){
	 int maxX=(int)(xScale/(step));
	 int maxY=(int)(yScale/(step));
	 
	 double t=g.EstimateThreshold(0,0, maxX, maxY);
	 System.out.println("Threshold is:"+t);
}

public double computeThreshold(Grid g){
	 int maxX=(int)(xScale/step);
	 int maxY=(int)(yScale/step);
	 
	 double t=g.EstimateThreshold(0, 0, maxX,maxY);
	 
	 return t;
	 //g.setThreshold(t);
}*/
/*
public void testComponents(){
 	ToyLoad bf=new ToyLoad();
	LoadRes lr= bf.BrinkoffLoad("data/toy/toy.dat");
	bf.statisticAllCell(lr.resGrid);
	bf.prinMaxMin();
	bf.testThreshold(lr.resGrid);
	double ts=bf.computeThreshold(lr.resGrid);
	lr.resGrid.setThreshold(ts);
	
	
	//VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,50,50);
	
	// public QueryTra(Grid inGrid,TraStore inTraStore,double inLat0,double inLng0,double inStep,double inThreshold,int inQueryConstraintX, int inQueryConstraintY,int inQueryDivided)
	QueryTra qbt=new QueryTra(lr.resGrid,lr.resTraStore, bf.lat0, bf.lng0, bf.step, ts, 4, 4, 4);
	RoIState rs=lr.resGrid.findConstraintRoI(25, 25, 1, 1, 0.04);
	HashSet<RoICell>resRC=rs.roiSet;
	
	ArrayList<Point> gridPos=new ArrayList<Point>();
	gridPos.add(new Point(5,5));
	gridPos.add(new Point(35,35));
	
	Hashtable<Integer,TraListItem> interRes=qbt.QueryTraMultiCell(gridPos, 4, 4, 0.04);		
	  
	Hashtable<Integer,ArrayList<TraStoreListItem>> traSet
	  				= qbt.QueryFutureTraSet(interRes, 10, lr.resTraStore);
	
	qbt.visitQueryResult(interRes, traSet); 
	
	//vg.visQueryResult(interRes, traSet,bf.step,bf.lat0,bf.lng0);
	
	//public GridFilter(Grid inGrid,
	//		Hashtable<Integer, ArrayList<TraStoreListItem>> inQueryResult,
	//		double inLat0, double inLng0, double inStep) {

	lr.resGrid.setEnlargeR(1);
	GridFilter gf=new GridFilter(lr.resGrid,traSet,bf.lat0,bf.lng0,bf.step);
	gf.visitTimeTraState();
	gf.visitW_kk();
	//gf.visitTimeQueryRes();
	//gf.TimeQueryRes2RoiStateSet();
	//gf.visitRoIStateSet();
 }
*/
/*
private void test1(){
	 ToyLoad bf=new ToyLoad();
	 LoadRes lr= bf.BrinkoffLoad("data/toy/toy.dat");
	 
	 VisGrid vg=VisGrid.visGridPart(lr.resGrid, 0, 0,50,50);
	 
	// public QueryTra(Grid inGrid,TraStore inTraStore,double inLat0,double inLng0,double inStep,double inThreshold,int inQueryConstraintX, int inQueryConstraintY,int inQueryDivided)
	QueryTra qbt=new QueryTra(lr.resGrid,lr.resTraStore, 
			bf.lat0, bf.lng0, bf.step, lr.resGrid.getGlobalThreshold(), 4, 4, 4);
	
	ArrayList<TraStoreListItem>  recentTra=bf.loadRecentTra("data/toy/query.dat");
	
	Hashtable<Integer,ArrayList<TraStoreListItem>> traSet=qbt.QueryByRecentTra(recentTra, 10);
	qbt.visitQueryFutureTra(traSet);
	vg.setDrawMap(false);
	//vg.visQueryResult( traSet,bf.lat0,bf.lng0,bf.step);
	
	
	
	lr.resGrid.setEnlargeR(1);
	GridFilter gf=new GridFilter(lr.resGrid,traSet,bf.lat0,bf.lng0,bf.step);
	gf.MAPEsitmation();
	gf.visitMAPPath();
	
	
	
	vg.visTimeTraState(gf.timeTraState);
	//gf.visitTimeTraState();
	//gf.visitW_kk();
	//qbt.QueryByRecentTra(recentTra, inFutureTime)
	
	 
}*/



