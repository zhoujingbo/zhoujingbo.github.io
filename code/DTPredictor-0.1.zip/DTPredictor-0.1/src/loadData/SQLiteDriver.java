package loadData;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public class SQLiteDriver {
	public static Connection conn;
	public static ResultSet rs;
	
	/**
	 * Open DB, togather with closeDB and exeSQL
	 * @param db
	 */
	public static void openDB(String db){
		try {
			Class.forName("org.sqlite.JDBC");
		
		String conStr="jdbc:sqlite:"+db;
		 conn = DriverManager.getConnection(conStr);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * close DB, with openDB and exeSQL
	 */
	public static void closeDB(){
		try {
		conn.close();
		rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * with opendb and closedb
	 * @param sql
	 */
	public static void exeSQL(String sql){
		try{
		 Statement stat = conn.createStatement(); 
		
		 rs = stat.executeQuery(sql);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param db
	 * @param timeStart
	 * @param timeEnd
	 * @return there are five elements, and they are [minLat,minLng,maxLat,maxLng,num of taxi]
	 */
	public static double[] getMaxMinNum(String db,String table,String timeStart,String timeEnd){
		double[] res=new double[5];
		
		try {
			openDB( db);
			 String sql="select min(lat),min(lng),max(lat),max(lng),count(distinct  id) from "+table
			 + " where time>time(\""+timeStart+"\") and time<time(\""+timeEnd+"\")";
			 
			 exeSQL(sql);
			 
			 while(rs.next()){
				 res[0]=rs.getDouble(1);
				 res[1]=rs.getDouble(2);
				 res[2]=rs.getDouble(3);
				 res[3]=rs.getDouble(4);
				 res[4]=rs.getInt(5);
			 }
			 closeDB();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	//important, by time order
	public static void loadTaxiDB(String table,String timeStart,String timeEnd){
		String sql= "select * from "+
		 table+ " where time>time(\""+timeStart+"\") and time<time(\""+timeEnd+"\") order by time asc";
		exeSQL(sql);
	}
	
	
	
	//important, by time order
	public static void loadTaxiDB(String table,String timeStart,String timeEnd,String status){
		String sql= "select * from "+
		 table+ " where time>time(\""+timeStart+"\") and time<time(\""+timeEnd+"\")"+" and status='"+status+"' order by time asc";
		exeSQL(sql);
	}
	
	//important, by time order
	public static void loadWxgVideoTraDB(String table, int timeStart,int timeEnd){
		String sql= "select * from "+
		 table+ " where t>"+timeStart+" and t<"+timeEnd+" order by t asc";
		exeSQL(sql);
	}
	
	//by time order
	public static void loadBBFOld(String table, int timeStart, int timeEnd){
		String sql= "select id,seq,x,y,t from "+
		 table+ " where t>"+timeStart+" and t<"+timeEnd+" order by t asc";
		exeSQL(sql);
	}
	
	public static int[] getMITTraStartEndId(String db,String table, int timeStart, int timeEnd){
		int[] res= new int[2];;
		try {
			openDB( db);
			 String sql="select min(id),max(id) from "+table
			 + " where t>"+timeStart+" and t<"+timeEnd+"";
			 
			 exeSQL(sql);
			
			 while(rs.next()){
				 res[0]=rs.getInt(1);
				 res[1]=rs.getInt(2);
			 }
			 closeDB();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			res=null;
			e.printStackTrace();
		}
		
		
		return res;
	}
	
	public static int getSeconds(String str){

		String[] resStr=str.split(":|,");
		int h=Integer.parseInt(resStr[0]);
		int m=Integer.parseInt(resStr[1]);
		int s=Integer.parseInt(resStr[2]);
		
		return h*3600+m*60+s;
	}
	
	
	public static void test()  {
		
        try {
			Class.forName("org.sqlite.JDBC");
		
        Connection conn = DriverManager.getConnection("jdbc:sqlite:data/taxi/test.db");
        Statement stat = conn.createStatement();
        stat.executeUpdate("drop table if exists people;");
        stat.executeUpdate("create table people (name, occupation);");
        PreparedStatement prep = conn.prepareStatement(
            "insert into people values (?, ?);");

        prep.setString(1, "Gandhi");
        prep.setString(2, "politics");
        prep.addBatch();
        prep.setString(1, "Turing");
        prep.setString(2, "computers");
        prep.addBatch();
        prep.setString(1, "Wittgenstein");
        prep.setString(2, "smartypants");
        prep.addBatch();

        conn.setAutoCommit(false);
        prep.executeBatch();
        conn.setAutoCommit(true);

        ResultSet rs = stat.executeQuery("select * from people;");
        while (rs.next()) {
            System.out.println("name = " + rs.getString("name"));
            System.out.println("job = " + rs.getString("occupation"));
        }
        rs.close();
        conn.close();
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void testTime() throws SQLException{

		
		//double[] x=getMaxMinNum("data/taxi/taxi.db","test","00:00:03","00:00:10");
		openDB("data/taxi/taxi.db");
		loadTaxiDB("taxi","08:00:00","08:00:04");
		while(rs.next()){
		Time ts=rs.getTime("time");
		String str=rs.getString("time");
		System.out.println(SQLiteDriver.getSeconds(str));
		//int l=getSeconds(str);
		//System.out.println(l);
		
		//double lat=rs.getDouble("lat");
		//System.out.println(lat);
		}
		closeDB();
	
	}
	
	public static void testgetMaxMinNum(){
		double[] res=SQLiteDriver.getMaxMinNum("data/taxi/taxi.db","taxi","08:00:00","12:00:10");
		for(double ri:res){
			System.out.println(ri);
		}
		
	}
	public static void main(String[] args) throws Exception {
		
		testgetMaxMinNum();
	}
		
	
}
