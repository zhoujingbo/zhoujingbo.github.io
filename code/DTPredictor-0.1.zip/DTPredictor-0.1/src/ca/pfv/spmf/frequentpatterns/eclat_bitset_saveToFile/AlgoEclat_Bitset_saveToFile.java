package ca.pfv.spmf.frequentpatterns.eclat_bitset_saveToFile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * This is an implementation of the ECLAT algorithm as proposed by ZAKI (2000).
 * 
 * NOTE: This version implement TIDs sets as bit vectors.  Note however 
 * that Zaki have proposed other optimizations (e.g. diffset), not used here.
 *
 * Copyright (c) 2008-2012 Philippe Fournier-Viger
 * 
 * This file is part of the SPMF DATA MINING SOFTWARE
 * (http://www.philippe-fournier-viger.com/spmf).
 *
 * SPMF is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SPMF is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SPMF.  If not, see <http://www.gnu.org/licenses/>.
 */
public class AlgoEclat_Bitset_saveToFile {

	private long startTimestamp; // for stats
	private long endTimestamp; // for stats
	private int minsupRelative;
	
	Map<Integer, BitSet> mapItemTIDS = new HashMap<Integer, BitSet>();
	
	int tidcount;
	BufferedWriter writer = null;
	private int itemsetCount;

	public AlgoEclat_Bitset_saveToFile() {
		
	}

	/**
	 * This algorithm has two parameters
	 * @param minsupp the minimum support
	 * @param itemCount
	 * @throws IOException 
	 */
	public void runAlgorithm(String input, String output, double minsup) throws IOException {
		startTimestamp = System.currentTimeMillis();
		writer = new BufferedWriter(new FileWriter(output)); 

		// (1) count the tid set of each item in the database in one database pass
		mapItemTIDS = new HashMap<Integer, BitSet>(); // id item, count
		BufferedReader reader = new BufferedReader(new FileReader(input));
		String line;
		tidcount=0;
		while( ((line = reader.readLine())!= null)){ // for each transaction
			String[] lineSplited = line.split(" ");
			for(String stringItem : lineSplited){
				int item = Integer.parseInt(stringItem);
				BitSet tids = mapItemTIDS.get(item);
				if(tids == null){
					tids = new BitSet();
					mapItemTIDS.put(item, tids);
				}
				tids.set(tidcount);
			}
			tidcount++;
		}
		reader.close();
		
		this.minsupRelative = (int) Math.ceil(minsup * tidcount);
				
		// (2) create ITSearchTree with root node
		ITSearchTree tree = new ITSearchTree();
		ITNode root = new ITNode(new HashSet<Integer>());
		root.setTidset(null, tidcount);
		tree.setRoot(root);
		
		// (3) create childs of the root node.
		for(Entry<Integer, BitSet> entry : mapItemTIDS.entrySet()){
			int entryCardinality = entry.getValue().cardinality();
			// we only add nodes for items that are frequents
			if(entryCardinality >= minsupRelative){
				// create the new node
				Set<Integer> itemset = new HashSet<Integer>();
				itemset.add(entry.getKey());
				ITNode newNode = new ITNode(itemset);
				newNode.setTidset(entry.getValue(), entryCardinality);
				newNode.setParent(root);
				// add the new node as child of the root node
				root.getChildNodes().add(newNode); 
			}
		}
		
		// for optimization
		sortChildren(root);
		
		while(root.getChildNodes().size() > 0){
			ITNode child = root.getChildNodes().get(0);
			extend(child);
			save(child);
			delete(child);
		}

		endTimestamp= System.currentTimeMillis();
		writer.close();
	}

	private void extend(ITNode currNode) throws IOException {
		// loop over the brothers
		for(ITNode brother : currNode.getParent().getChildNodes()){
			if(brother != currNode){
				ITNode candidate = getCandidate(currNode,brother);
				if(candidate != null){
					currNode.getChildNodes().add(candidate);
					candidate.setParent(currNode);
				}
			}
		}
		
		sortChildren(currNode);

		while(currNode.getChildNodes().size() > 0){
			ITNode child = currNode.getChildNodes().get(0);
			extend(child);
			save(child);
			delete(child);
		}
	}
	
	private ITNode getCandidate(ITNode currNode, ITNode brother) {

		// create list of common tids.
		BitSet commonTids = (BitSet)currNode.getTidset().clone();
		commonTids.and(brother.getTidset());
		int cardinality = commonTids.cardinality();
		
		// (2) check if the two itemsets have enough common tids
		// if not, we don't need to generate a rule for them.
		if(cardinality >= minsupRelative){
			Set<Integer> union = new HashSet<Integer>(brother.getItemset());
			union.addAll(currNode.getItemset());
			ITNode node = new ITNode(union);
			node.setTidset(commonTids, cardinality);
			return node;
		}
		
		return null;
	}

	private void delete(ITNode child) {
		child.getParent().getChildNodes().remove(child);
	}

	private void save(ITNode node) throws IOException {
		writer.write(node.getItemset().toString() + " Support: " + node.cardinality + " / " + tidcount + " = " + node.getRelativeSupport(tidcount));
		writer.newLine();
		itemsetCount++;
	}

	private void sortChildren(ITNode node) {
		// sort children of the node according to the support.
		Collections.sort(node.getChildNodes(), new Comparator<ITNode>(){
			//Returns a negative integer, zero, or a positive integer as 
			// the first argument is less than, equal to, or greater than the second.
			public int compare(ITNode o1, ITNode o2) {
				return o1.getTidset().size() - o2.getTidset().size();
			}
		});
	}

	public void printStats() {
		System.out
				.println("=============  ECLAT - STATS =============");
		long temps = endTimestamp - startTimestamp;
		System.out.println(" Transactions count from database : "
				+ tidcount);
		System.out.println(" Frequent itemsets count : " + itemsetCount); 
		System.out.println(" Total time ~ " + temps + " ms");
		System.out
				.println("===================================================");
	}

}
