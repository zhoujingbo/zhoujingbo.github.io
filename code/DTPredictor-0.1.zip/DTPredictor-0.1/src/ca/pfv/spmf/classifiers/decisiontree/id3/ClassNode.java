package ca.pfv.spmf.classifiers.decisiontree.id3;

public class ClassNode extends Node{
	String className;

}
