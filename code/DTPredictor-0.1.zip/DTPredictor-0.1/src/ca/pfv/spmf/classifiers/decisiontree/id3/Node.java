package ca.pfv.spmf.classifiers.decisiontree.id3;

public class Node {

}
