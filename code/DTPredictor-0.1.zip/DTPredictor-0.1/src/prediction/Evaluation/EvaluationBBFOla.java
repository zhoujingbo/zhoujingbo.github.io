package prediction.Evaluation;

import grid.Configuration;
import grid.Grid;
import grid.GridLeafTraHashItem;
import grid.RoICell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import TrajPrefixSpan.PatternConfiguration;
import TrajPrefixSpan.PatternPredictor;

import loadData.BBFOldLoad;
import loadData.TaxiLoad;
import loadData.WxgVideoTraLoad;


import prediction.MacroState;
import prediction.Predictor;
import prediction.StateGridFilter;
import stp.predictor.MotionPredictor;
import stp.predictor.Point;

public class EvaluationBBFOla {

	
public static void main(String args[]){
		
	
		
		expPredictionErro();
	
	//expResTimePredictionLen_new();
	
	//expPredictionError_prefixSpan();
	}
	

	public static void expPredictionErro(){
		
		Predictor pdr=new Predictor();

		BBFOldLoad tl=new BBFOldLoad();
		
		Configuration.BITS_PER_GRID=4;
		Configuration.MAX_LEVEL=3;
		Configuration.GridDivided=2048;
		
				
			
		Configuration.T_Sample=1;
		Configuration.BBFOldXMin=292.0;
		Configuration.BBFOldYMin=3935.0;
		Configuration.BBFOldXMax=23056.0;
		Configuration.BBFOldYMax=30851.0;
		Configuration.BBFOldTraNum=2010;
		
		Configuration.T_Sample=1;
		Configuration.T_period=200;
		
		Configuration.BrinkConstraintRoI=16; 
		Configuration.BrinkThreshold=2.0;
		Configuration.TraSupport=1;
		
		//define parameter related with MacroState and MicroState 
		Configuration.MaxRadius=5000; //maximum size of state, not import parameters. It is defined on real distance
		Configuration.MaxStateDis=500;
		Configuration.AlphaRadius=1.5;//should be larger than 1
		Configuration.AlphaScore=1/16.0;
		Configuration.ProDown=0.2;
		Configuration.MAPPro=0.2;
		
		Configuration.MicroStateRadius=Configuration.cellRadius*2;
		
		int velocityLimit=0;
		
		int refTime=4;
		//int testLen=25;
		
		int DBBackStep=3;
		int STPBackStep=5;
		
		int sampleNum=1000;
		int sampleLen=25;
		
		int timeStart=2;
		int timeEnd=200;
		
		int sampleStart=2;
		int sampleEnd=200;
		
		tl.setSample(sampleNum, sampleLen,sampleStart,sampleEnd);
		
		Grid g=tl.Load2Grid("data/BigBrinkhoff/bigBrinkhoff.db", "BBFOldTest17",timeStart ,timeEnd);
		
		
		//VisGrid vg=VisGrid.visGridPart(g, 512, 512,2048,2048);//show a map
		
		HashMap<Integer, ArrayList<RoICell>> gridRes=tl.getGridSampleList();
		HashMap<Integer,ArrayList<stp.predictor.Point>> locRes=tl.getLocSampleList();
		
		Iterator<Entry<Integer,ArrayList<RoICell>>> lItr=gridRes.entrySet().iterator();
		//int avgCount=0;
		int[] avgCount=new int[sampleLen+refTime];
		double[] avgDT=new double[sampleLen+refTime];
		double[] avgSTP=new double[sampleLen+refTime];
		int stpCount=0;
		for(int j=0;j<sampleLen+refTime;j++){
			avgDT[j]=0;
			avgSTP[j]=0;
			avgCount[j]=0;
		}
		
		double countSum=gridRes.size();
		int vlCount=0;
		while(lItr.hasNext()){
			
			long dtStart=0,dtEnd=0;
			long stpStart=0,stpEnd=0;
			Entry<Integer,ArrayList<RoICell>> gridItem=lItr.next();
		
			ArrayList<RoICell> rcGridList=gridItem.getValue();
			//ArrayList<stp.predictor.Point> rcLocList=locRes.get(gridItem.getKey());
			
			ArrayList<RoICell> ref=new ArrayList<RoICell>(rcGridList.subList(refTime-DBBackStep+1, refTime+1));
			RoICell r1=ref.get(0);
			RoICell r2=ref.get(1);
			
			if(Math.abs(r1.roiX-r2.roiX)<=velocityLimit&&Math.abs(r1.roiY-r2.roiY)<=velocityLimit){
				vlCount++;
				continue;
			}
			
			dtStart=System.currentTimeMillis();
			 ArrayList<Entry<Long, GridLeafTraHashItem>>  testBres=g.queryRangeTimeSeqCells(ref);
			 if(null==testBres||testBres.size()<Configuration.TraSupport) continue;
			
			 StateGridFilter sgf=pdr.PathPrediction(testBres,g,Configuration.ProDown,Configuration.MAPPro,Configuration.MicroStateRadius);
			 ArrayList<MacroState> mp=sgf.gfStates.getMacroStatePath();
			  dtEnd=System.currentTimeMillis();
			
				 long dtTime=dtEnd-dtStart;
				 long stpTime=0;
				 int len=mp.size()-1;
				
			
				
				 for(int i=1;i<=len;i++){
					 
					 MacroState pItem=mp.get(i);
					 if(i+refTime>rcGridList.size()-1){
						 continue;
					 }
					 RoICell tItem=rcGridList.get(i+refTime);
					 double d_dt=pItem.getDisCenter(tItem.roiX, tItem.roiY);
					 //for debug
					// System.out.println("t:"+i+" "+"DT error:"+d_dt);
					 avgDT[i]+=d_dt;
					
				// }
				// System.out.println("time DT:"+dtTime+" STP:"+stpTime);
				 avgCount[i]++;	 
			 }
		}
		
		Iterator<Entry<Integer,ArrayList<stp.predictor.Point>>> rcLocItr=locRes.entrySet().iterator();
		stpCount=0;
		while(rcLocItr.hasNext()){
			long stpStart=0,stpEnd=0;
			 long stpTime=0;
			Entry<Integer,ArrayList<stp.predictor.Point>> locItem=rcLocItr.next();
			ArrayList<stp.predictor.Point> rcLocList=locItem.getValue();
			 
			 stpStart=System.currentTimeMillis();

			 List<stp.predictor.Point> stpRef= rcLocList.subList(refTime-STPBackStep+1, refTime+1);
			 stp.predictor.Point p1=stpRef.get(0);
			 stp.predictor.Point p2=stpRef.get(1);
			// if(Math.abs(p2.x-p1.x)<3||
			//		 Math.abs(p2.y-p1.y)<3){
			//	 continue;
			// }
			 stpCount++;
			 ArrayList<stp.predictor.Point> stpP=MotionPredictor.STPLocPredictor(stpRef, sampleLen-refTime);

			 
			 stpEnd=System.currentTimeMillis();
			stpTime=stpEnd-stpStart;
		for(int j=1;j<sampleLen-refTime;j++){
			 stpStart=System.currentTimeMillis();
			 
			 stp.predictor.Point locItemTrue=rcLocList.get(j+refTime);
			 stp.predictor.Point stpItem=stpP.get(j-1);
			 stpEnd=System.currentTimeMillis();
			 stpTime+=stpEnd-stpStart;
			 double d_stp=stpItem.distance(locItemTrue.x, locItemTrue.y);//
			 //for debug
			// System.out.println("t:"+j+" "+"STP error:"+d_stp);
			 avgSTP[j]+=d_stp;
		}
		}
		
		
		
		//System.out.println(avgCount);
		//int countSum=10;//for debug 
		//int vlCount=2;
		System.out.println("#time	count	Rate	DT_error	RMF error");
		for(int i=1;i<avgDT.length;i++){
			System.out.println(i+"	"+avgCount[i]+"	"+avgCount[i]/(countSum-vlCount)+"	"+avgDT[i]/avgCount[i]*9+"	"+avgSTP[i]/stpCount);
		}
	
		System.out.print("#stp count:"+stpCount);
	}
	
	


	

	public static void expResTimePredictionLen_new(){

		Predictor pdr=new Predictor();

		BBFOldLoad tl=new BBFOldLoad();
		
		Configuration.BITS_PER_GRID=4;
		Configuration.MAX_LEVEL=3;
		Configuration.GridDivided=2048;
		
				
			
		Configuration.T_Sample=1;
		Configuration.BBFOldXMin=292.0;
		Configuration.BBFOldYMin=3935.0;
		Configuration.BBFOldXMax=23056.0;
		Configuration.BBFOldYMax=30851.0;
		Configuration.BBFOldTraNum=100000;
		
		Configuration.T_Sample=1;
		Configuration.T_period=200;
		
		Configuration.BrinkConstraintRoI=16; 
		Configuration.BrinkThreshold=2.0;
		Configuration.TraSupport=1;
		
		//define parameter related with MacroState and MicroState 
		Configuration.MaxRadius=5000; //maximum size of state, not import parameters. It is defined on real distance
		Configuration.MaxStateDis=500;
		Configuration.AlphaRadius=1.5;//should be larger than 1
		Configuration.AlphaScore=1/16.0;
		Configuration.ProDown=0.2;
		Configuration.MAPPro=0.2;
		
		Configuration.MicroStateRadius=Configuration.cellRadius*2;
		
		int velocityLimit=0;
		
		int refTime=4;
		//int testLen=25;
		
		int DBBackStep=3;
		int STPBackStep=5;
		
		int sampleNum=500;
		int sampleLen=25;
		
		int timeStart=2;
		int timeEnd=200;
		
		int sampleStart=100;
		int sampleEnd=200;
		
		tl.setSample(sampleNum, sampleLen,sampleStart,sampleEnd);
		
		long startLoad=System.currentTimeMillis();
		Configuration.BBFOldTraNum=100000;
		Grid g=tl.Load2Grid("data/BigBrinkhoff/bigBrinkhoff.db", "BBFOldTest13",timeStart ,timeEnd);
		long endLoad=System.currentTimeMillis();
		System.out.println("Historical trajectories loading time:"+(endLoad-startLoad)+" ms");
		
		
		double MAPpro=0.2;
		
		int top=20;
		
		int[] traTimeSlotCount=new int[10];
		long[] traTimeSlotSum=new long[10];
		
		for(int j=0;j<10;j++){
			traTimeSlotCount[j]=0;
			traTimeSlotSum[j]=0;
		}
		
		
	//	System.out.println("#average Response Time cost 15:00_16:00");
		//System.out.println("#MAP	query_time(ms)	prediction_time(ms)	total(ms)	top20_query(ms)	top20_prediction(ms)	top20(ms)");
		
		//while(MAPpro<0.9){
			
			Configuration.GridFile+=MAPpro;
			Configuration.MAPPro=MAPpro;
			
			

		
			

		
	
		
		
		//VisGrid vg=VisGrid.visGridPart(g, 512, 512,2048,2048);//show a map
		
		HashMap<Integer, ArrayList<RoICell>> gridRes=tl.getGridSampleList();
		HashMap<Integer,ArrayList<stp.predictor.Point>> locRes=tl.getLocSampleList();
		
		Iterator<Entry<Integer,ArrayList<RoICell>>> lItr=gridRes.entrySet().iterator();
		//int avgCount=0;
		int[] avgCount=new int[sampleLen+refTime];
		double[] avgDT=new double[sampleLen+refTime];
		double[] avgSTP=new double[sampleLen+refTime];
		int stpCount=0;
		for(int j=0;j<sampleLen+refTime;j++){
			avgDT[j]=0;
			avgSTP[j]=0;
			avgCount[j]=0;
		}
		
		int traCount=0;
		long queryTime = (long)0;
		long predictionTime=(long)0;
		long sumPredictionTime=(long)0;
		int sumCount=0;
		ArrayList<Long> queryTimeArray=new ArrayList<Long>();
		ArrayList<Long> predictionTimeArray=new ArrayList<Long>();
		ArrayList<Long> DTTimeArray=new ArrayList<Long>();
		while(lItr.hasNext()){
			
			
			Entry<Integer,ArrayList<RoICell>> gridItem=lItr.next();
		
			ArrayList<RoICell> rcGridList=gridItem.getValue();
			ArrayList<stp.predictor.Point> rcLocList=locRes.get(gridItem.getKey());
			
			ArrayList<RoICell> ref=new ArrayList<RoICell>(rcGridList.subList(refTime-DBBackStep+1, refTime+1));
			RoICell r1=ref.get(0);
			RoICell r2=ref.get(1);
			
			if(Math.abs(r1.roiX-r2.roiX)<=velocityLimit&&Math.abs(r1.roiY-r2.roiY)<=velocityLimit){
			
				continue;
			}
			
			long queryItemStart=System.currentTimeMillis();
			 ArrayList<Entry<Long, GridLeafTraHashItem>>  testBres=g.queryRangeTimeSeqCells(ref);
			 long queryItemEnd=System.currentTimeMillis();
			 long queryItemTime=queryItemEnd-queryItemStart;
			 if(null==testBres||testBres.size()<Configuration.TraSupport) continue;
			
			 traCount++;
			 queryTime+=queryItemTime;
			 queryTimeArray.add(queryItemTime);
			 
			 long preItemStart=System.currentTimeMillis();
			 StateGridFilter sgf=pdr.PathPrediction(testBres,g,Configuration.ProDown,Configuration.MAPPro,Configuration.MicroStateRadius);
			 long preItemEnd=System.currentTimeMillis();
			 
			 long preItemTime=preItemEnd-preItemStart;
			 predictionTimeArray.add(preItemTime);
			 predictionTime+=preItemTime;
			 DTTimeArray.add(queryItemTime+preItemTime);
			 ArrayList<MacroState> mp=sgf.gfStates.getMacroStatePath();
			 
			 int mpLen=mp.size();
			 switch(mpLen){
			 case 0:{
				 sumCount++;
				 break;
			 }
			 case 1:{
				 traTimeSlotCount[0]++;
				 traTimeSlotSum[0]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 2:{
				 traTimeSlotCount[1]++;
				 traTimeSlotSum[1]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 3:{
				 traTimeSlotCount[2]++;
				 traTimeSlotSum[2]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 4:{
				 traTimeSlotCount[3]++;
				 traTimeSlotSum[3]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 5:{
				 traTimeSlotCount[4]++;
				 traTimeSlotSum[4]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 6:{
				 traTimeSlotCount[5]++;
				 traTimeSlotSum[5]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 7:{
				 traTimeSlotCount[6]++;
				 traTimeSlotSum[6]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 8:{
				 traTimeSlotCount[7]++;
				 traTimeSlotSum[7]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 9:{
				 traTimeSlotCount[8]++;
				 traTimeSlotSum[8]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 case 10:{
				 traTimeSlotCount[9]++;
				 traTimeSlotSum[9]+=preItemEnd-preItemStart;
				 sumPredictionTime+=preItemEnd-preItemStart;
				 sumCount++;
				 break;
			 }
			 default: 
				 break;
			 }
			
		}
		
		String[] label=new String[10];
		label[0]="1 s";
		label[1]="2 s";
		label[2]="3 s";
		label[3]="4 s";
		label[4]="5 s";
		label[5]="6 s";
		label[6]="7 s";
		label[7]="8 s";
		label[8]="9 s";
		label[9]="10 s";
		
		System.out.println("# average response time:"+predictionTime/sampleNum);
		System.out.println("# total count:"+traCount);
		System.out.println("#BBFOld 200 Predict_t_len count	response_t");
		
		for(int i=0;i<10;i++){
			System.out.println(label[i]+"	"+traTimeSlotCount[i]+"	"+traTimeSlotSum[i]/1./traTimeSlotCount[i]);
		}
	
	
	
	}
	
	

	public static void expPredictionError_prefixSpan(){
			

		PatternConfiguration.GridDivision=1024;
		PatternConfiguration.TrajDB="data/BigBrinkhoff/bigBrinkhoff.db";
		PatternConfiguration.TrajTable="BBFOldTest17";
		
		PatternConfiguration.T_sample=1;
		PatternConfiguration.ExtremLowVelocityLat=0;
		PatternConfiguration.ExtremLowVelocityLng=0;
		
		Configuration.BBFOldXMin=292.0;
		Configuration.BBFOldYMin=3935.0;
		Configuration.BBFOldXMax=23056.0;
		Configuration.BBFOldYMax=30851.0;
		
		PatternConfiguration.LatMin=Configuration.BBFOldXMin;
		PatternConfiguration.LngMin=Configuration.BBFOldYMin;
		PatternConfiguration.LatMax= Configuration.BBFOldXMax;
		PatternConfiguration.LngMax=Configuration.BBFOldYMax;
		PatternConfiguration.GridDivision=1024;
		
		//public static int SequenceLen=40;//if equal -1, turnoff this function
	
		
			
			PatternPredictor patternPredictor=new PatternPredictor();
			
			
			
			//patternPredictor.CalibrationParameter(PatternConfiguration.LatMin,PatternConfiguration.LngMin,
			//		 PatternConfiguration.LatMax, PatternConfiguration.LngMax,PatternConfiguration.GridDivision);
			long startLoading=System.currentTimeMillis();
			String fptreeStr="FPTree/BBFOld/BBFOldTest17_s-1_e-50_sup-5_div-1024_seqLen--1.fptree";
			patternPredictor.readPatternFP(fptreeStr);
			long endLoading=System.currentTimeMillis();
			System.out.println("#High of FP tree:"+patternPredictor.patternFP.getHight());
			System.out.println("#loading time of FPtree:"+(endLoading-startLoading)+ " ms");
			System.out.println("Using FPTree:"+fptreeStr);
			
			//TaxiLoad tl=new TaxiLoad();
			BBFOldLoad tl=new BBFOldLoad();
		
			

		
			int refTime=4;
			//int testLen=25;
			
			int DBBackStep=3;
			int STPBackStep=5;
			int prefixSpanBack=3;
			
			int sampleNum=1000;
			int sampleLen=25;
			
			int timeStart=2;
			int timeEnd=100;
			
			int sampleStart=60;
			int sampleEnd=100;
			int sampleSkip=4;
			
			double[] avgPrefixSpan=new double[2*sampleLen+refTime];
			int[]	prefixSpanCount=new int[2*sampleLen+refTime];
			
			for(int j=0;j<sampleLen+refTime;j++){
			
				avgPrefixSpan[j]=0;
				prefixSpanCount[j]=0;
			}
			PatternConfiguration.TrajNum=200000;
			ArrayList<ArrayList<Point>> sampleRes=tl.sampleFromDB("data/BigBrinkhoff/bigBrinkhoff.db", "BBFOldTest17",sampleStart ,sampleEnd ,
					sampleNum,sampleLen,sampleSkip);
			
			long startPrediction=System.currentTimeMillis();
			int prefixSpanSumCount=sampleRes.size();
			for(int i=0;i<sampleRes.size();i++){
			
				ArrayList<Point> rcLocList=sampleRes.get(i);
				
			 List<stp.predictor.Point> prefixSpanRef= rcLocList.subList(refTime-prefixSpanBack+1, refTime+1);
			 ArrayList<stp.predictor.Point> prefixSpanRes=patternPredictor.PrefixSpanWholePredictorReal(new ArrayList<stp.predictor.Point>(prefixSpanRef), 0);//MotionPredictor.STPLocPredictor(stpRef, sampleLen-refTime);

			
				
				
				for(int j=1;j<prefixSpanRes.size()+1&&j+refTime<rcLocList.size();j++){
					 
					 
					 stp.predictor.Point locItemTrue=rcLocList.get(j+refTime);
					 stp.predictor.Point stpItem=prefixSpanRes.get(j-1);
				
					 double d_stp=stpItem.distance(locItemTrue.x, locItemTrue.y);//
					 //for debug
					// System.out.println("t:"+j+" "+"STP error:"+d_stp);
					 avgPrefixSpan[j]+=d_stp;
					 prefixSpanCount[j]++;
				}
				
			}
			long endPrediction=System.currentTimeMillis();
			System.out.println("#Pattern count:"+prefixSpanSumCount);
			System.out.println("#prediction time:"+(endPrediction-startPrediction)+" ms");
			//System.out.println(avgCount);
			System.out.println("#timePrefixSpan(s) count Rate PrefixSpan error");
			for(int i=1;i<avgPrefixSpan.length;i++){
				System.out.println(i+" "+prefixSpanCount[i]+"	"+((double)prefixSpanCount[i])/prefixSpanSumCount+" "+avgPrefixSpan[i]/prefixSpanCount[i]*1);
			}
			
			System.out.println("total count:"+prefixSpanSumCount);
			
		}
	
}
